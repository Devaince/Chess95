from django.db import models

class users(models.Model):
	user_name = models.CharField( max_length=50,default = "")
	password = models.CharField(  max_length=50,default = "")
	mail =	models.EmailField(max_length=50,default = "")
	be_active = models.BooleanField(default = "")
	activate_code = models.IntegerField(default=11111)
	game_board = models.CharField(max_length=8 * 64,default = "")	
# Create your models here.
