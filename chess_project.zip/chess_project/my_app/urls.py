from .views import *
from django.conf.urls import url
app_name = 'my_app'
urlpatterns = [
	url(r'^$', home_site , name='home'),
	url(r'^signin/$', signin_site, name='signin_site'),
	url(r'^signup/$', signup_site, name='signup_site'),
	url(r'^activation/$', giving_signup_information , name='giving_signup_information'),
]
