from django.shortcuts import render

# Create your views here.


import json
from my_app.models import users
from django.shortcuts import *
from django.http import *
from django.core.mail import *
from random import *
#from Desktop import 3chess
'''
table = [["**" for i in range(8)] for j in range(8)]
for i in range(8):
    table[1][i] = "wp"
    table[6][i] = "bp"

table[0][0] = "wr"    
table[0][7] = "wr"
table[7][0] = "br"
table[7][7] = "br"
# rokh


table[0][1] = "wn"
table[0][6] = "wn"
table[7][1] = "bn"
table[7][6] = "Bn"
# asb

table[0][2] = "wb"
table[0][5] = "wb"
table[7][2] = "bb"
table[7][5] = "bb"
# fil

table[0][3] = "wk"
table[7][3] = "bk"
# shah


table[0][4] = "wq"
table[7][4] = "bq"
#vazir
'''






"""image_of_chess_pices = {'wr': 'IMGs/wr.png', 'wk': 'IMGs/wk.png', 'wn': 'IMGs/wn.png', 'wp': 'IMGs/wp.png',
                        'wq': 'IMGs/wq.png', 'bb': 'IMGs/bb.png', 'bk': 'IMGs/bk.png', 'bn': 'IMGs/bn.png',
                        'bp': 'IMGs/bp.png', 'bq': 'IMGs/bq.png', 'br': 'IMGs/br.png', '**': 'IMGs/em.gif',
                        'wb': 'IMGs/wb.png'}

for i in range(8):
    for j in range(8):
        table[i][j] = image_of_chess_pices[table[i][j]]
"""
def home_site(request):
    return render(request, 'my_app/home.html')

def signin_site(request):
    return render(request, "my_app/signin.html")

def signup_site(request):
    return render(request, "my_app/signup.html")

def activate_site(request):
    return render(request, "my_app/home.html")

def giving_signup_information(request):

    user_valid = users.objects.filter(user_name = request.POST["username"])
    #username va password va password_confirm va mail to ye html esme input toye form
    if(user_valid ):
    	error = "This Username already been taken!"	
    	error_dict = {'template_error' : error}
    	return render(request, 'my_app/signup.html', error_dict)
    user_adding = request.POST["username"]
    password = request.POST["password"]
    password_confirm = request.POST["password_confirm"]
    mail = request.POST["mail"]
    
    if(password != password_confirm):
        error = " wrong password!!!"
        error_dict = {"template_error" : error}
        return render(request, 'my_app/signup.html', error_dict)
        #error toye template
    random_code = randint(10000, 99999)
    send_mail(
        'Hello dear' + str(user_adding) + ' youre activation key is : ' + str(random_code),
        "hey." + str(user_adding),
        'icp95.project@gmail.com',
        [mail],
        fail_silently = False
    )    


    game_board = making_table(table)

    sample_user = users(user_name = user_valid,mail = mail ,password = password, activate_code = random_code,
    be_active = 0, game_board = game_board)

    sample_user.save() 
    context = {'user': sample_user, 'board' : table}
    return render(request, 'my_app/activate.html', context)




"""tmp = json.dumps(table)
user=users()
user.user_name=user_invalid
user.password=password
user.mail=mail
user.game_board=tmp
user.save()
tmp1=json.loads(user.game_board)
"""
"""def making_table(table):
    string = ""
    for i in range(8):
        for j in range(8):
            srtring += table[i][j]
    return string
def giving_signin_information(request):
    return render(request)
"""
